using System;
using System.Web;
using System.Net;

namespace Astrila.Eq2Img
{
	/// <summary>
	/// Summary description for convert.
	/// </summary>
	public class Convert : IHttpHandler
	{
		void IHttpHandler.ProcessRequest ( System.Web.HttpContext context )
		{
			using (WebClient browser = new WebClient())
			{
				byte[] imageData = browser.DownloadData(context.Request.Url.AbsoluteUri.Replace("convert.ashx","cgi/mimetex.exe")+"?wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWwww");
				context.Response.ContentType = "image/gif";
				context.Response.BinaryWrite(imageData);
				context.Response.End();
			}
		}
		bool IHttpHandler.IsReusable
		{
			get
			{
				return true;
			}
		}
	}
}
